package com.cg.pizzaorder.service;

import com.cg.pizzaorder.bean.Customer;
import com.cg.pizzaorder.bean.PizzaOrder;
import com.cg.pizzaorder.dao.IPizzaOrderDAO;
import com.cg.pizzaorder.dao.PizzaOrderDAO;
import com.cg.pizzaorder.exception.PizzaOrderException;

public class PizzaOrderService implements IPizzaOrderservice{
IPizzaOrderDAO dao=new PizzaOrderDAO();
	@Override
	public int placeOrder(Customer customer, PizzaOrder pizza)
			throws PizzaOrderException {
		int p=dao.placeOrder(customer, pizza);
		return p;
	}

	@Override
	public PizzaOrder getOrderDetails(int orderid) throws PizzaOrderException {
		PizzaOrder po=dao.getOrderDetails(orderid);
		return po;
	}

}
