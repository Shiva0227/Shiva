package com.cg.pizzaorder.service;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.cg.pizzaorder.bean.Customer;
import com.cg.pizzaorder.bean.PizzaOrder;
import com.cg.pizzaorder.exception.PizzaOrderException;

public interface IPizzaOrderservice {
	public int placeOrder(Customer customer,PizzaOrder pizza) throws PizzaOrderException;
	public PizzaOrder getOrderDetails(int orderid) throws PizzaOrderException;
	public static boolean validatephone(String phone){
		Pattern p=Pattern.compile("[0-9]{10}");
		Matcher m=p.matcher(phone);
		if(m.matches()){
			return true;
		}
		System.out.println("Please enter the 10 Digit valid MobileNumber");
		System.exit(0);
		return false;
			
	}
}
