package com.cg.pizzaorder.junit;

import java.lang.annotation.Target;

import org.junit.Assert;
import org.junit.Test;

import com.cg.pizzaorder.bean.Customer;
import com.cg.pizzaorder.bean.PizzaOrder;
import com.cg.pizzaorder.dao.IPizzaOrderDAO;
import com.cg.pizzaorder.dao.PizzaOrderDAO;

public class TestCase {
		IPizzaOrderDAO dao=null; 
	@BeforeClass
		public void setUp()
		{
			dao=new PizzaOrderDAO();
		} 
	@Test
		public static int placeOrder(Customer customer, PizzaOrder pizza) throws PizzaOrderException
		{
			Assert.assertEquals(customer,pizza);
		}
	@AfterClass
		public static PizzaOrder getOrderDetails(int orderid){
			Assert.assertEquals(orderid);
		} 
	} 

