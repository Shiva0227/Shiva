package com.cg.pizzaorder.exception;

public class PizzaOrderException extends Exception{

	public PizzaOrderException(String arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

}
