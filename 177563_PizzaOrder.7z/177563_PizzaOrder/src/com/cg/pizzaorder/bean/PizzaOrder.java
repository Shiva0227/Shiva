package com.cg.pizzaorder.bean;

public class PizzaOrder {
private int orderId;
private int customerid;
private double totalPrice;
public PizzaOrder() {
	super();
}
public PizzaOrder(int orderId, int customerid, double totalPrice) {
	super();
	this.orderId = orderId;
	this.customerid = customerid;
	this.totalPrice = totalPrice;
}
public int getOrderId() {
	return orderId;
}
public void setOrderId(int orderId) {
	this.orderId = orderId;
}
public int getCustomerid() {
	return customerid;
}
public void setCustomerid(int customerid) {
	this.customerid = customerid;
}
public double getTotalPrice() {
	return totalPrice;
}
public void setTotalPrice(double totalPrice) {
	this.totalPrice = totalPrice;
}
@Override
public String toString() {
	return "PizzaOrder [orderId=" + orderId + ", customerid=" + customerid
			+ ", totalPrice=" + totalPrice + "]";
}
}
