package com.cg.pizzaorder.dao;

import com.cg.pizzaorder.bean.Customer;
import com.cg.pizzaorder.bean.PizzaOrder;
import com.cg.pizzaorder.exception.PizzaOrderException;
import com.cg.pizzaorder.util.CollectionUtil;

public class PizzaOrderDAO implements IPizzaOrderDAO{

	@Override
	public int placeOrder(Customer customer, PizzaOrder pizza)
			throws PizzaOrderException {
		int p=CollectionUtil.placeOrder(customer, pizza);
		return p;
	}

	@Override
	public PizzaOrder getOrderDetails(int orderid) throws PizzaOrderException {
		PizzaOrder po=CollectionUtil.getOrderDetails(orderid);
		return po;
	}

}
