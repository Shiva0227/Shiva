package com.cg.pizzaorder.ui;

import java.time.LocalDate;
import java.util.Scanner;

import com.cg.pizzaorder.bean.Customer;
import com.cg.pizzaorder.bean.PizzaOrder;
import com.cg.pizzaorder.exception.PizzaOrderException;
import com.cg.pizzaorder.service.IPizzaOrderservice;
import com.cg.pizzaorder.service.PizzaOrderService;

public class Client {

	static Scanner sc=null;
	static IPizzaOrderservice pos=null;
	public static void main(String[] args) throws PizzaOrderException{
		sc=new Scanner(System.in);
		pos=new PizzaOrderService();
			System.out.println("PIZZA TOPPINGS \t PRICE(IN RUPEES)");
			System.out.println("Capsicum \t 30");
			System.out.println("Mushroom \t 30");
			System.out.println("Jalapeno \t 70");
			System.out.println("Paneer   \t 85");
			System.out.println();
			while(true){
			int choice=0;
			System.out.println("Enter Your Choice");
			System.out.println("1:PLACE ORDER\n2:DISPLAY ORDER\n3:EXIT");
			choice=sc.nextInt();
			switch(choice){
			case 1:	
				placeOrder();
				break;
			case 2:
				getPizzaOrder();
				break;
			case 3:System.out.println("Quitted From Application");
				System.exit(0);
			default:
					System.out.println("try again");
			}
			}
	}
			public static void placeOrder() throws PizzaOrderException{
				System.out.println("Enter Customer Name:");
				String name=sc.next();
				System.out.println("Enter Customer Address:");
				String address=sc.next();
				try{	
				System.out.println("Enter Customer Phone Number:");
				String phone=sc.next();
				if(IPizzaOrderservice.validatephone(phone));
				System.out.println("Type of Pizza Topping Preferred:");
				while(true){
					String type;
					int Capsicum=30;
					int Mushroom=50;
					int Jalepeno=70;
					int Paneer=85;
					int price=350;
					type=sc.next();
					switch(type){
					case "Capsicum":
						price+=Capsicum;
						break;
					case "Mushroom":
						price+=Mushroom;
						break;
					case "Jalepeno":
						price+=Jalepeno;
						break;
					case "Paneer":
						price+=Paneer;
						break;
						default:
							System.out.println("Try again");	
					}
				System.out.println("Enter Price To Calculate:"+price);
				//double price=(350+sc.nextDouble());
				System.out.println("OrderDate:"+LocalDate.now());
				int orderid=(int)(Math.random()*5000);
				int customerid=(int)(Math.random()*5000);
				Customer customer=new Customer(customerid,name,address,phone);
				PizzaOrder pizza=new PizzaOrder(orderid,customerid,price);
				int p=pos.placeOrder(customer, pizza);
				System.out.println("Pizza Order Successfully Placed With OrderId:"+p);
				break;
				}
				}
			catch(Exception e){
				System.out.println(e);
			}
				}
			public static void getPizzaOrder() throws PizzaOrderException{
				System.out.println("Enter OrderId To Display Order Details:");
				int orderid=sc.nextInt();
				PizzaOrder po=pos.getOrderDetails(orderid);
				System.out.println(po);
			}
			

}
