package com.cg.pizzaorder.util;

import java.util.HashMap;
import java.util.Map;

import com.cg.pizzaorder.bean.Customer;
import com.cg.pizzaorder.bean.PizzaOrder;

public class CollectionUtil {
static Map<Integer,PizzaOrder> pizzaentry=new HashMap<>();
static{
	pizzaentry.put(1111,new PizzaOrder(1111,1001,20000.0));
	pizzaentry.put(2222,new PizzaOrder(2222,1002,30000.0));
}
static Map<Integer,Customer> customerentry=new HashMap<>();
static{
	customerentry.put(1001,new Customer(1001,"Rkreddy","AP","9632587413"));
	customerentry.put(1002,new Customer(1002,"Vijay","HYD","9632587415"));
}
public static int placeOrder(Customer customer, PizzaOrder pizza){
	pizzaentry.put(pizza.getOrderId(), pizza);
	customerentry.put(customer.getCustomerId(), customer);
	return pizza.getOrderId();	
}
public static PizzaOrder getOrderDetails(int orderid){
	return pizzaentry.get(orderid);
}

}
